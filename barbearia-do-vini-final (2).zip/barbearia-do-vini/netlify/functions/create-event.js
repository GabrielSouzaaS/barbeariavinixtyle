// netlify/functions/create-event.js
// Cria um evento no Google Calendar quando o cliente confirma o agendamento.

const { google } = require('googleapis');

// Duração em minutos por serviço
const DURACOES = {
  'Corte – R$30':            30,
  'Barba – R$20':            20,
  'Combo – R$44,90':         50,
  'Plano Mensal – R$104,90': 30,
};

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Método não permitido.' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Body inválido.' }) };
  }

  const { nome, servico, data, hora } = body;

  if (!nome || !servico || !data || !hora) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Campos nome, servico, data e hora são obrigatórios.' }),
    };
  }

  try {
    const auth = new google.auth.GoogleAuth({
      credentials: {
        type: 'service_account',
        project_id: process.env.GOOGLE_PROJECT_ID,
        private_key_id: process.env.GOOGLE_PRIVATE_KEY_ID,
        private_key: (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
        client_email: process.env.GOOGLE_CLIENT_EMAIL,
        client_id: process.env.GOOGLE_CLIENT_ID,
      },
      scopes: ['https://www.googleapis.com/auth/calendar.events'],
    });

    const calendar = google.calendar({ version: 'v3', auth });

    const duracao  = DURACOES[servico] || 30;
    const startISO = new Date(`${data}T${hora}:00-03:00`).toISOString();
    const endISO   = new Date(new Date(startISO).getTime() + duracao * 60000).toISOString();

    await calendar.events.insert({
      calendarId: process.env.GOOGLE_CALENDAR_ID,
      requestBody: {
        summary: `✂️ ${servico} — ${nome}`,
        description: `Cliente: ${nome}\nServiço: ${servico}\nAgendado pelo site.`,
        start: { dateTime: startISO, timeZone: 'America/Sao_Paulo' },
        end:   { dateTime: endISO,   timeZone: 'America/Sao_Paulo' },
        colorId: '5', // banana/dourado
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'popup', minutes: 60 },
            { method: 'popup', minutes: 10 },
          ],
        },
      },
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ok: true, message: 'Agendamento criado no Google Calendar.' }),
    };

  } catch (err) {
    console.error('Erro ao criar evento:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Falha ao criar o agendamento.', detail: err.message }),
    };
  }
};
