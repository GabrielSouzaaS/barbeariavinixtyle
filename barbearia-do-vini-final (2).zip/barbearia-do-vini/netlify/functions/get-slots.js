// netlify/functions/get-slots.js
// Busca eventos do Google Calendar e retorna horários já ocupados
// para a data e serviço informados.

const { google } = require('googleapis');

// Duração em minutos de cada serviço
const DURACOES = {
  'Corte – R$30':          30,
  'Barba – R$20':          20,
  'Combo – R$44,90':       50,
  'Plano Mensal – R$104,90': 30,
};

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json',
  };

  // Preflight CORS
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const { data, servico } = event.queryStringParameters || {};

  if (!data || !servico) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Parâmetros data e servico são obrigatórios.' }),
    };
  }

  try {
    // Autenticação via Service Account (credenciais definidas em variáveis de ambiente)
    const auth = new google.auth.GoogleAuth({
      credentials: {
        type: 'service_account',
        project_id: process.env.GOOGLE_PROJECT_ID,
        private_key_id: process.env.GOOGLE_PRIVATE_KEY_ID,
        private_key: (process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
        client_email: process.env.GOOGLE_CLIENT_EMAIL,
        client_id: process.env.GOOGLE_CLIENT_ID,
      },
      scopes: ['https://www.googleapis.com/auth/calendar.readonly'],
    });

    const calendar = google.calendar({ version: 'v3', auth });

    // Intervalo: dia inteiro na timezone de Brasília
    const inicio = new Date(`${data}T00:00:00-03:00`).toISOString();
    const fim    = new Date(`${data}T23:59:59-03:00`).toISOString();

    const res = await calendar.events.list({
      calendarId: process.env.GOOGLE_CALENDAR_ID,
      timeMin: inicio,
      timeMax: fim,
      singleEvents: true,
      orderBy: 'startTime',
    });

    const duracao = DURACOES[servico] || 30;

    // Extrai horários ocupados (considera bloqueio pelo tempo de duração do serviço)
    const ocupados = (res.data.items || [])
      .filter(ev => ev.start?.dateTime)
      .map(ev => {
        const start = new Date(ev.start.dateTime);
        const end   = ev.end?.dateTime ? new Date(ev.end.dateTime) : new Date(start.getTime() + duracao * 60000);
        return {
          inicio: start.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' }),
          fim:    end.toLocaleTimeString('pt-BR',   { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' }),
        };
      });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ocupados }),
    };

  } catch (err) {
    console.error('Erro ao buscar slots:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Falha ao consultar o calendário.', detail: err.message }),
    };
  }
};
