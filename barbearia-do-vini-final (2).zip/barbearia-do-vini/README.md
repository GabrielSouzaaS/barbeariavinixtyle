# Barbearia do Vini — Setup Google Calendar + Netlify

## Estrutura do projeto

```
barbearia-do-vini/
├── index.html                        ← site principal
├── netlify.toml                      ← configuração do Netlify
└── netlify/
    └── functions/
        ├── package.json              ← dependência: googleapis
        ├── get-slots.js              ← busca horários ocupados
        └── create-event.js           ← cria evento ao agendar
```

---

## 1. Criar Service Account no Google Cloud

1. Acesse https://console.cloud.google.com
2. Selecione seu projeto (ou crie um novo)
3. Menu → **APIs e serviços → Credenciais**
4. Clique em **+ Criar credenciais → Conta de serviço**
5. Dê um nome (ex: `barbearia-calendar`) e clique em **Criar e continuar**
6. Na tela de permissões, pule e clique em **Concluído**
7. Clique na conta criada → aba **Chaves → Adicionar chave → JSON**
8. Um arquivo `.json` será baixado — guarde-o com segurança

---

## 2. Ativar a Google Calendar API

1. Acesse https://console.cloud.google.com/apis/library/calendar-json.googleapis.com
2. Clique em **Ativar**

---

## 3. Compartilhar seu Google Calendar com a Service Account

1. Abra **Google Calendar** (calendar.google.com)
2. No calendário da barbearia, clique nos 3 pontos → **Configurações e compartilhamento**
3. Em **Compartilhar com pessoas específicas**, adicione o e-mail da Service Account
   (ex: `barbearia-calendar@seu-projeto.iam.gserviceaccount.com`)
4. Permissão: **Fazer alterações em eventos**
5. Copie também o **ID do Calendário** (em "Integrar agenda" → ID da agenda)

---

## 4. Configurar variáveis de ambiente no Netlify

No painel do Netlify: **Site → Environment variables → Add variable**

| Variável                  | Onde encontrar no JSON da Service Account |
|---------------------------|-------------------------------------------|
| `GOOGLE_PROJECT_ID`       | campo `project_id`                        |
| `GOOGLE_PRIVATE_KEY_ID`   | campo `private_key_id`                    |
| `GOOGLE_PRIVATE_KEY`      | campo `private_key` (cole o valor inteiro, com `\n`) |
| `GOOGLE_CLIENT_EMAIL`     | campo `client_email`                      |
| `GOOGLE_CLIENT_ID`        | campo `client_id`                         |
| `GOOGLE_CALENDAR_ID`      | ID do calendário copiado no passo 3       |

---

## 5. Deploy no Netlify

```bash
# Opção A — via Netlify CLI
npm install -g netlify-cli
netlify login
netlify deploy --prod

# Opção B — via GitHub
# 1. Suba a pasta para um repositório no GitHub
# 2. No Netlify: Add new site → Import from Git → selecione o repo
# 3. Build command: (deixe vazio)
# 4. Publish directory: .
```

---

## 6. Adicionar fotos da galeria

No `index.html`, localize a seção `<!-- GALERIA -->` e substitua os placeholders por imagens reais:

```html
<!-- Antes (placeholder) -->
<div class="galeria-placeholder">✂️<span>Em breve</span></div>

<!-- Depois (foto real) -->
<div class="galeria-item">
  <img src="fotos/corte-01.jpg" alt="Corte degradê" loading="lazy" />
</div>
```

Coloque as fotos na pasta `fotos/` ao lado do `index.html`.

---

## 7. Como funciona o agendamento

1. Cliente escolhe serviço + data → JS chama `/.netlify/functions/get-slots`
2. A function consulta o Google Calendar e retorna horários ocupados
3. Horários ocupados aparecem riscados e desabilitados
4. Cliente seleciona horário livre e clica em confirmar
5. JS chama `/.netlify/functions/create-event` → evento criado no Calendar
6. WhatsApp abre com mensagem pré-preenchida para confirmação final

---

## Suporte
Em caso de dúvidas, verifique os logs das functions em:
**Netlify → Functions → get-slots / create-event → Log**
